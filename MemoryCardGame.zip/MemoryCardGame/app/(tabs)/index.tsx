import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from "react-native";

const emojis = ["🍎", "🍌", "🍇", "🍉", "🥝", "🍒", "🍍", "🥥"];

function shuffle(array: any[]) {
  return array.sort(() => Math.random() - 0.5);
}

export default function HomeScreen() {
  const [cards, setCards] = useState<any[]>([]);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);

  useEffect(() => {
    startGame();
  }, []);

  function startGame() {
    const deck = shuffle(
      [...emojis, ...emojis].map((emoji, index) => ({
        id: index,
        emoji,
      }))
    );

    setCards(deck);
    setFlipped([]);
    setMatched([]);
    setMoves(0);
  }

  function handlePress(index: number) {
    if (
      flipped.includes(index) ||
      matched.includes(index) ||
      flipped.length === 2
    )
      return;

    const newFlipped = [...flipped, index];
    setFlipped(newFlipped);

    if (newFlipped.length === 2) {
      setMoves((m) => m + 1);

      const first = cards[newFlipped[0]];
      const second = cards[newFlipped[1]];

      if (first.emoji === second.emoji) {
        setMatched([...matched, newFlipped[0], newFlipped[1]]);
        setFlipped([]);

        if (matched.length + 2 === 16) {
          Alert.alert("🎉 Congratulations!", "You won the game!");
        }
      } else {
        setTimeout(() => {
          setFlipped([]);
        }, 800);
      }
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🧠 Memory Card Game</Text>

      <Text style={styles.info}>Moves: {moves}</Text>

      <View style={styles.board}>
        {cards.map((card, index) => {
          const show =
            flipped.includes(index) || matched.includes(index);

          return (
            <TouchableOpacity
              key={index}
              style={styles.card}
              onPress={() => handlePress(index)}
            >
              <Text style={styles.cardText}>
                {show ? card.emoji : "🂠"}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <TouchableOpacity style={styles.button} onPress={startGame}>
        <Text style={styles.buttonText}>Restart Game</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#4A90E2",
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
  },

  title: {
    fontSize: 30,
    fontWeight: "bold",
    color: "white",
    marginBottom: 20,
  },

  info: {
    color: "white",
    fontSize: 20,
    marginBottom: 20,
  },

  board: {
    width: 320,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
  },

  card: {
    width: 70,
    height: 70,
    backgroundColor: "white",
    margin: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
  },

  cardText: {
    fontSize: 30,
  },

  button: {
    marginTop: 30,
    backgroundColor: "#FF9800",
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 10,
  },

  buttonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
});